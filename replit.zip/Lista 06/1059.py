comeco, fim = 1, 100
for x in range(comeco, fim + 1):
   if x % 2 == 0:
      print(f"{x}")